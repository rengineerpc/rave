export const environment = {
  production: true,
  backendUrl: 'http://localhost:3000'
};
